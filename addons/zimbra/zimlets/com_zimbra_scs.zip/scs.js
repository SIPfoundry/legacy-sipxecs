/*
 ///////////////////////////////////////////////////////////////////////////////////////
 *
 *  Copyright (C) 2009 Nortel, certain elements licensed under a Contributor Agreement.
 *  Contributors retain copyright to elements licensed under a Contributor Agreement.
 *  Licensed to the User under the LGPL license.
 *
 * $$
 ///////////////////////////////////////////////////////////////////////////////////////
 */

function com_zimbra_scs() {
}
com_zimbra_scs.prototype = new ZmZimletBase();
com_zimbra_scs.prototype.constructor = com_zimbra_scs;

com_zimbra_scs.prototype.init =
function() {
	var regexps = [];
	var o = this.xmlObj().contentObject.matchOn[0];
	var a = o.regex;
	for (var i = 0; i < a.length; ++i) {
		o = a[i];
		var attrs = o.attrs;
		if (!attrs)
		{
			attrs = "ig";
		}

		var re = new RegExp(o._content, attrs);
		if (o.paren !== null)
		{
			re.useParen = parseInt(o.paren);
		}

		regexps.push(re);
	}
	this.regexps = regexps;

	this._initializePreferences();

	this._initializeAddressBook();
};

com_zimbra_scs.prototype.getClick2CallURL =
function(phoneNumberToCall) {
	if (this.scs_sslenabled == 1)
	{
		return "https://" + this.scs_server + ":" + this.scs_port + "/callcontroller/" + this.scs_user+"/" + phoneNumberToCall;
	}

	return "http://" + this.scs_server + ":" + this.scs_port + "/callcontroller/" + this.scs_user+"/" + phoneNumberToCall;
};

com_zimbra_scs.prototype.getClick2CallURL2 =
function(fromNumber, phoneNumberToCall) {
	var url;

	if (this.scs_sslenabled == 1)
	{
		url = "https://" + this.scs_server + ":" + this.scs_port+ "/callcontroller/" + fromNumber +"/" + phoneNumberToCall;
	}
	else
	{

		url = "http://" + this.scs_server + ":" + this.scs_port + "/callcontroller/" + fromNumber +"/" + phoneNumberToCall;
	}

	var params= ["agent=" + AjxStringUtil.urlComponentEncode(this.scs_user),
			"timeout=" + AjxStringUtil.urlEncode("30")
			].join ("&");

	return url + "?" + params;
};

com_zimbra_scs.prototype.doubleClicked =
function() {	
	this.singleClicked();
};

com_zimbra_scs.prototype.singleClicked =
function() {	
		this._showCallDlg("");
};

com_zimbra_scs.prototype.toolTipPoppedUp =
function(spanElement, contentObjText, matchContext, canvas) {
	var presence;
	var theContact = this._getContactByPhone(contentObjText);

	if (theContact != null)
	{		
		presence = this._queryPresence(theContact._otherIM);
		if (presence.unified_presence)
		{
			canvas.innerHTML = "Call: "+ contentObjText + " [" + presence.unified_presence + "]";
			return;
		}
	}
	
	canvas.innerHTML = "Call: "+ contentObjText + " [presence unknown]";
};

//===========
com_zimbra_scs.prototype._clickToCall =
function(toPhoneNumber) {
	var hdrs = [];
	if (this.scs_sslenabled == 1)
	{
		hdrs.Authorization = this.make_basic_auth(this.scs_user, this.scs_password);
	}
	var feedUrl = ZmZimletBase.PROXY + AjxStringUtil.urlComponentEncode(this.getClick2CallURL(toPhoneNumber));
	AjxRpc.invoke(null, feedUrl, hdrs, new AjxCallback(this, this._reponseHandler), false);
};
com_zimbra_scs.prototype._clickToCall2 =
function(callingNumber, toPhoneNumber) {
	var hdrs = [];
	if (this.scs_sslenabled == 1)
	{
		hdrs.Authorization = this.make_basic_auth(this.scs_user, this.scs_password);
	}
	var feedUrl = ZmZimletBase.PROXY + AjxStringUtil.urlComponentEncode(this.getClick2CallURL2(callingNumber, toPhoneNumber));
	AjxRpc.invoke(null, feedUrl, hdrs, new AjxCallback(this, this._reponseHandler), false);
};
com_zimbra_scs.prototype._reponseHandler =
function(response) {

	if (!response.success)
	{
		alert("Failed to call! status:" + response.status + "\n" + response.text);
	}

};
//===========


com_zimbra_scs.prototype.make_basic_auth =
function (user, password) {
  var tok = user + ':' + password;
  var hash = Base64.encode(tok);
  return "Basic " + hash;
};




//called by zimbraCore when link is clicked
com_zimbra_scs.prototype.clicked = 
function(myElement, toPhoneNumber) {
	this._showCallDlg(toPhoneNumber);
};

com_zimbra_scs.prototype.doDrop = function(obj) {
	switch (obj.TYPE) {
	    case "ZmMailMsg":
		this.msgDropped(obj);
		break;
	    case "ZmConv":
		this.convDropped(obj);
		break;

	    case "ZmContact":
		this.contactDropped(obj);
		break;

	    case "ZmAppt":
		this.apptDropped(obj);
		break;

	    default:
		this.displayErrorMessage("You somehow managed to drop a \"" + obj.TYPE + 
					 "\" but however this Zimlet does't support it for drag'n'drop.");
	}
};

com_zimbra_scs.prototype.apptDropped = function(zmObject) {
	
	var loc = zmObject.location;
	var calledNumber;

	var i = loc.indexOf("SCS@BN ");
	if (i === 0 && loc.length > "SCS@BN ".length)
	{
		var str =  loc.substr(i + "SCS@BN ".length);
		var endi = str.indexOf(" ");
		if (endi !== -1)
		{
			calledNumber = str.substring(0, endi);
		}
		else
		{
			calledNumber = str;
		}
		
		this._showCallDlg(calledNumber);
	}

	else
	{
		alert("No valid conference number found from Location");
		return;
	}

};

com_zimbra_scs.prototype.msgDropped = function(msg) 
{
	try 
	{
		var fromEmail = msg.from ;
		var respCallback = new AjxCallback(this, this._callContact, fromEmail);
		var transitions = [ ZmToast.FADE_IN, ZmToast.PAUSE, ZmToast.PAUSE, ZmToast.PAUSE, ZmToast.PAUSE, ZmToast.PAUSE, ZmToast.FADE_OUT ];
		appCtxt.getAppController().setStatusMsg("Please wait, scanning Address Book for Contact " + fromEmail + " phone numbers..", ZmStatusView.LEVEL_INFO, null, transitions);
		appCtxt.getApp(ZmApp.CONTACTS).getContactByEmail(fromEmail, respCallback);
	}

	catch(err)
	{
		  txt="There was an error on this page.\n\n";
		  txt+="Error description: " + err.description + "\n\n";
		  txt+="Click OK to continue.\n\n";
		  alert(txt);
	}
};
com_zimbra_scs.prototype.convDropped = function(conv) 
{
	try 
	{
		var fromEmail = conv.participants[0].address;
		var respCallback = new AjxCallback(this, this._callContact, fromEmail);
		var transitions = [ ZmToast.FADE_IN, ZmToast.PAUSE, ZmToast.PAUSE, ZmToast.PAUSE, ZmToast.PAUSE, ZmToast.PAUSE, ZmToast.FADE_OUT ];
		appCtxt.getAppController().setStatusMsg("Please wait, scanning Address Book for Contact " + fromEmail + " phone numbers..", ZmStatusView.LEVEL_INFO, null, transitions);
		appCtxt.getApp(ZmApp.CONTACTS).getContactByEmail(fromEmail, respCallback);
	}

	catch(err)
	{
		  txt="There was an error on this page.\n\n";
		  txt+="Error description: " + err.description + "\n\n";
		  txt+="Click OK to continue.\n\n";
		  alert(txt);
	}
};

com_zimbra_scs.prototype.contactDropped = function(zmObject) {
	this._showChooseDlg(zmObject, false);
};

com_zimbra_scs.prototype._callContact = function(email, contact, isContactSrcObj) {

	if(contact === undefined || contact === null) {
		appCtxt.getAppController().setStatusMsg("No Contact found for this email: "+email, ZmStatusView.LEVEL_WARNING);
		return;
	} 

	if(isContactSrcObj === undefined)
	{
		isContactSrcObj = true;
	}

	this._showChooseDlg(contact, isContactSrcObj);
	return;
};

com_zimbra_scs.prototype._showPreferenceDlg = function() {
	if (this._preferenceDialog) {
		this._preferenceDialog.popup();
	}
	else
	{
		this._preferenceView = new DwtComposite(this.getShell());
		this._preferenceView.getHtmlElement().style.overflow = "auto";
		this._preferenceView.getHtmlElement().innerHTML = this._createPrefView();
		this._preferenceDialog = this._createDialog({title:"SCS Preferences", view:this._preferenceView, standardButtons:[DwtDialog.OK_BUTTON, DwtDialog.CANCEL_BUTTON]});
		this._preferenceDialog.setButtonListener(DwtDialog.OK_BUTTON, new AjxListener(this, this._okPreferenceBtnListener));
		this._preferenceDialog.popup();
	}

	this._setZimletCurrentPreferences();
};

com_zimbra_scs.prototype._createPrefView =
function() {
	var html = [];
	var i = 0;
	html[i++] = "<TABLE>";
	html[i++] = "<TR>";
	html[i++] = "<TD>";
	html[i++] = "SCS Server: ";
	html[i++] = "</TD><TD>";
	html[i++] = "<input id='scs_server'  type='text'/>";
	html[i++] = "</TD>";
	html[i++] = "</TR>";
	html[i++] = "<TR>";
	html[i++] = "<TD>";
	html[i++] = "</TD><TD>";
	html[i++] = "<input id='scs_sslenabled'  type='checkbox'/>SSL Enabled";
	html[i++] = "</TD>";
	html[i++] = "</TR>";
	html[i++] = "<TR>";
	html[i++] = "<TD>";
	html[i++] = "SCS port: ";
	html[i++] = "</TD><TD>";
	html[i++] = "<input id='scs_port'  type='text'/>";
	html[i++] = "</TD>";
	html[i++] = "</TR>";
	html[i++] = "<TR>";
	html[i++] = "<TD>";
	html[i++] = "Presence port: ";
	html[i++] = "</TD><TD>";
	html[i++] = "<input id='presence_port'  type='text'/>";
	html[i++] = "</TD>";
	html[i++] = "</TR>";
	html[i++] = "<TR>";
	html[i++] = "<TD>";
	html[i++] = "SCS User: ";
	html[i++] = "</TD><TD>";
	html[i++] = "<input id='scs_user'  type='text'/>";
	html[i++] = "</TD>";
	html[i++] = "</TR>";
	html[i++] = "<TR>";
	html[i++] = "<TD>";
	html[i++] = "SCS Password:";
	html[i++] = "</TD><TD>";
	html[i++] =" <input id='scs_password'  type='password'/>";
	html[i++] = "</TD>";
	html[i++] = "</TR>";
	html[i++] = "<TR>";
	html[i++] = "<TD>";
	html[i++] = "Prefix to remove:";
	html[i++] = "</TD><TD>";
	html[i++] =" <input id='prefix_remove'  type='text'/>";
	html[i++] = "</TD>";
	html[i++] = "</TR>";
	html[i++] = "<TR>";
	html[i++] = "<TD>";
	html[i++] = "Prefix to add:";
	html[i++] = "</TD><TD>";
	html[i++] =" <input id='prefix_add'  type='text'/>";
	html[i++] = "</TD>";
	html[i++] = "</TR>";
	html[i++] = "</TABLE>";
	return html.join("");
};

com_zimbra_scs.prototype._convertB2I =
function(val)
{
	if (val === true)
	{
		return 1;
	}

	if (val === false)
	{
		return 0;
	}
};

com_zimbra_scs.prototype._convertI2B =
function(val)
{
	if (val == 1)
	{
		return true;
	}
	if (val == 0)
	{
		return false;
	}
};

com_zimbra_scs.prototype._initializePreferences =
function() {
	this.scs_user =  this.getUserProperty("scs_user");
	this.scs_password =  this.getUserProperty("scs_password");
	this.scs_server =  this.getUserProperty("scs_server");
	this.scs_port=  this.getUserProperty("scs_port");
	this.presence_port=  this.getUserProperty("presence_port");
	this.scs_sslenabled=  this.getUserProperty("scs_sslenabled");
	this.prefix_remove =  this.getUserProperty("prefix_remove");
	this.prefix_add =  this.getUserProperty("prefix_add");

	this._saveConf();
};

com_zimbra_scs.prototype._setZimletCurrentPreferences =
function() {
	if(document.getElementById("scs_user")){
		document.getElementById("scs_user").value = this.scs_user;
	}
	if(document.getElementById("scs_password")){
		document.getElementById("scs_password").value = this.scs_password;
	}
	   
	if(document.getElementById("scs_server")){
		document.getElementById("scs_server").value = this.scs_server;
	}
	if(document.getElementById("scs_port")){
		document.getElementById("scs_port").value = this.scs_port;
	}
	if(document.getElementById("presence_port")){
		document.getElementById("presence_port").value = this.presence_port;
	}
	if(document.getElementById("scs_sslenabled")){
		document.getElementById("scs_sslenabled").checked = this._convertI2B(this.scs_sslenabled);
	}
	if(document.getElementById("prefix_remove")){
		document.getElementById("prefix_remove").value = this.prefix_remove;
	}
	if(document.getElementById("prefix_add")){
		document.getElementById("prefix_add").value = this.prefix_add;
	}
};

com_zimbra_scs.prototype._okPreferenceBtnListener =
function() {
	var _saveRequired = false;

	if(this.scs_user != document.getElementById("scs_user").value) 
	{
		this.scs_user = document.getElementById("scs_user").value;
		this.setUserProperty("scs_user",  document.getElementById("scs_user").value);
		_saveRequired = true;
	}
	if(this.scs_password != document.getElementById("scs_password").value) 
	{
		this.scs_password = document.getElementById("scs_password").value;
		this.setUserProperty("scs_password",  document.getElementById("scs_password").value);
		_saveRequired = true;
	}
	if(this.scs_port!= document.getElementById("scs_port").value) 
	{
		this.scs_port= document.getElementById("scs_port").value;
		this.setUserProperty("scs_port",  document.getElementById("scs_port").value);
		_saveRequired = true;
	}
	if(this.presence_port!= document.getElementById("presence_port").value) 
	{
		this.presence_port= document.getElementById("presence_port").value;
		this.setUserProperty("presence_port",  document.getElementById("presence_port").value);
		_saveRequired = true;
	}
	if(this.scs_sslenabled != this._convertB2I(document.getElementById("scs_sslenabled").checked)) 
	{
		this.scs_sslenabled = this._convertB2I(document.getElementById("scs_sslenabled").checked);
		this.setUserProperty("scs_sslenabled",  this._convertB2I(document.getElementById("scs_sslenabled").checked));
		_saveRequired = true;
	}
	if(this.scs_server != document.getElementById("scs_server").value) 
	{

		if (this._validateIP(document.getElementById("scs_server").value) || this._checkDomain(document.getElementById("scs_server").value))
		{
			this.scs_server = document.getElementById("scs_server").value;
			this.setUserProperty("scs_server",  document.getElementById("scs_server").value);
			_saveRequired = true;
		}
		else
		{
			alert("Pleae enter a valid server IP or domain name!");
			document.getElementById("scs_server").focus();
			return;
		}
	}
	if(this.prefix_remove!= document.getElementById("prefix_remove").value) 
	{
		if (this._checkForNumberOnlyReg(document.getElementById("prefix_remove").value))
		{
			this.prefix_remove = document.getElementById("prefix_remove").value;
			this.setUserProperty("prefix_remove",  document.getElementById("prefix_remove").value);
			_saveRequired = true;
		}
		else
		{
			alert("Pleae enter a prefix!(only numbers allowed)");
			document.getElementById("prefix_remove").focus();
			return;
		}
	}
	if(this.prefix_add!= document.getElementById("prefix_add").value) 
	{
		if (this._checkForNumberOnlyReg(document.getElementById("prefix_add").value))
		{
			this.prefix_add = document.getElementById("prefix_add").value;
			this.setUserProperty("prefix_add",  document.getElementById("prefix_add").value);
			_saveRequired = true;
		}
		else
		{
			alert("Pleae enter a prefix!(only numbers allowed)");
			document.getElementById("prefix_add").focus();
			return;
		}
	}


	this._preferenceDialog.popdown();
	if (_saveRequired) 
	{
		this.saveUserProperties(new AjxCallback(this, this._showpreferenceSavedDlg));
	}
};

com_zimbra_scs.prototype._showpreferenceSavedDlg =
function() {
	var transitions = [ ZmToast.FADE_IN, ZmToast.PAUSE,  ZmToast.FADE_OUT ];
	appCtxt.getAppController().setStatusMsg("Preferences Saved", ZmStatusView.LEVEL_INFO, null, transitions);
	this._saveConf();
};


com_zimbra_scs.prototype.menuItemSelected =
function(itemId) {
	switch (itemId) {
		case "SEARCH":		this._searchListener(); break;
		case "ADDCONTACT":	this._contactListener(); break;
		case "CALL":		this._showCallDlg(this._actionObject.toString()); break;
		case "PRESENCE":	this._showPresence(this._actionObject.toString()); break;
		case "scs_preferences": this._showPreferenceDlg();break;
	}
};

com_zimbra_scs.prototype._showPresence = 
function(contentObjText) {
	var theContact = this._getContactByPhone(contentObjText);
	var lastname = "unknown";
	var firstname = "unknown";
	var presence = {fullname:"unknown unknown", IM_Id:"unknown", cm : "N/A", up: "unknown", xmpp:"unknown", sip:"unknown", status: "unknown", errorCode:"unknown", errorInfo:"unknown"};
	if (theContact != null)
	{
		if (theContact._lastName)
		{
			lastname = theContact._lastName;
		}
		if (theContact._firstName)
		{
			firstname= theContact._firstName;
		}
		if (theContact._otherIM)
		{
			presence.IM_Id = theContact._otherIM;
		}
	

		presence.fullname = firstname + " " + lastname;
				
		var jsonobj = this._queryPresence(theContact._otherIM);
		if (jsonobj)
		{
			presence.status = jsonobj.status_code?jsonobj.status_code:"unknown";

			presence.errorCode =  jsonobj.error_code ?  jsonobj.error_code : "";
			presence.errorInfo =  jsonobj.error_info? jsonobj.error_info :"";
			if (jsonobj.custom_presence_message)
			{
				presence.cm = jsonobj.custom_presence_message;
			}
			if (jsonobj.unified_presence)
			{
				presence.up = jsonobj.unified_presence;
			}
			if (jsonobj.xmpp_presence)
			{
				presence.xmpp = jsonobj.xmpp_presence;
			}
			if (jsonobj.sip_presence)
			{
				presence.sip = jsonobj.sip_presence;
			}
		}
	}
	
	if (this._PresenceDialog) {

		this._PresenceDialog.popup();
		document.getElementById("PI_fullname").value = presence.fullname;
		document.getElementById("PI_fullname").size =  presence.fullname.length;
		document.getElementById("PI_unified_presence").value = presence.up;
		document.getElementById("PI_unified_presence").size = presence.up.length; 
		document.getElementById("PI_im_presence").value = presence.xmpp;
		document.getElementById("PI_im_presence").size = presence.xmpp.length; 
		document.getElementById("PI_phone_presence").value = presence.sip;
		document.getElementById("PI_phone_presence").size =  presence.sip.length;
		document.getElementById("PI_cm").value = presence.cm;
		document.getElementById("PI_cm").size =  presence.cm.length;
		document.getElementById("PI_status").value = presence.status;
		document.getElementById("PI_status").size =  presence.status.length;
		document.getElementById("PI_IM_Id").value = presence.IM_Id;
		document.getElementById("PI_IM_Id").size =  presence.IM_Id.length;
	}
	else
	{
		this._PresenceDialogView = new DwtComposite(this.getShell());
		this._PresenceDialogView.getHtmlElement().style.overflow = "auto";
		this._PresenceDialogView.getHtmlElement().innerHTML = this._createPresenceView(presence);

		this._PresenceDialog = this._createDialog({title:"Presence Info", view:this._PresenceDialogView, standardButtons:[DwtDialog.CANCEL_BUTTON]});
		this._PresenceDialog.popup();
	}

	var row1 = document.getElementById("id_presence_errorcode");
	var row2 = document.getElementById("id_presence_errorinfo");
	if (presence.status == "ok")
	{
		row1.style.display = 'none';
		row2.style.display = 'none';
	}
	else
	{
		row1.style.display = '';
		row1.style.display = '';
	}
};

com_zimbra_scs.prototype._createPresenceView =
function(presence) {
	var html = [];
	var i = 0;
	html[i++] = "<FORM>";
	html[i++] = "<TABLE>";
	html[i++] = "<TR>";
	html[i++] = "<TD>Query Status:";
	html[i++] = "</TD>";
	html[i++] = "<TD>";
	html[i++] = "<input id='PI_status'  size=" + presence.status.length + " type='text' value='" + presence.status+ "' readonly ='readonly'/>";
	html[i++] = "</TD>";
	html[i++] = "</TR>";
	html[i++] = "<TR id = 'id_presence_errorcode'>";
	html[i++] = "<TD>Error code:";
	html[i++] = "</TD>";
	html[i++] = "<TD>";
	html[i++] = "<input id='PI_error_code'  size=" + presence.errorCode.length + " type='text' value='" + presence.errorCode+ "' readonly ='readonly'/>";
	html[i++] = "</TD>";
	html[i++] = "</TR>";
	html[i++] = "<TR id = 'id_presence_errorinfo'>";
	html[i++] = "<TD>Error info:";
	html[i++] = "</TD>";
	html[i++] = "<TD>";
	html[i++] = "<input id='PI_error_info'  size=" + presence.errorInfo.length + " type='text' value='" + presence.errorInfo+ "' readonly ='readonly'/>";
	html[i++] = "</TD>";
	html[i++] = "</TR>";
	html[i++] = "<TR>";
	html[i++] = "<TD>IM Id:";
	html[i++] = "</TD>";
	html[i++] = "<TD>";
	html[i++] = "<input id='PI_IM_Id'  size=" + presence.IM_Id.length + " type='text' value='" + presence.IM_Id+ "' readonly ='readonly'/>";
	html[i++] = "</TD>";
	html[i++] = "</TR>";
	html[i++] = "<TR>";
	html[i++] = "<TD>Full Name:";
	html[i++] = "</TD>";
	html[i++] = "<TD>";
	html[i++] = "<input id='PI_fullname'  size=" + presence.fullname.length + " type='text' value='" + presence.fullname + "' readonly ='readonly'/>";
	html[i++] = "</TD>";
	html[i++] = "</TR>";
	html[i++] = "<TR>";
	html[i++] = "<TD>Unified Presence::";
	html[i++] = "</TD>";
	html[i++] = "<TD>";
	html[i++] = "<input id='PI_unified_presence'  size=" + presence.up.length + " type='text' value='" + presence.up + "' readonly ='readonly'/>";
	html[i++] = "</TD>";
	html[i++] = "</TR>";
	html[i++] = "<TR>";
	html[i++] = "<TD>IM Presence:";
	html[i++] = "</TD>";
	html[i++] = "<TD>";
	html[i++] = "<input id='PI_im_presence'  size=" + presence.xmpp.length + " type='text' value='" + presence.xmpp + "' readonly ='readonly'/>";
	html[i++] = "</TD>";
	html[i++] = "</TR>";
	html[i++] = "<TR>";
	html[i++] = "<TD>Phone Presence:";
	html[i++] = "</TD>";
	html[i++] = "<TD>";
	html[i++] = "<input id='PI_phone_presence'  size=" + presence.sip.length + " type='text' value='" + presence.sip+ "' readonly ='readonly'/>";
	html[i++] = "</TD>";
	html[i++] = "</TR>";
	html[i++] = "<TR>";
	html[i++] = "<TD>Custom Message:";
	html[i++] = "</TD>";
	html[i++] = "<TD>";
	html[i++] = "<input id='PI_cm'  size=" + presence.cm.length + " type='text' value='" + presence.cm+ "' readonly ='readonly'/>";
	html[i++] = "</TD>";
	html[i++] = "</TR>";
	html[i++] = "</TABLE>";
	html[i++] = "</FORM>";
	return html.join("");
};

com_zimbra_scs.prototype._searchListener =
function() {
	appCtxt.getSearchController().search({query: this._actionObject});
};

com_zimbra_scs.prototype._contactListener =
function() {
	var contact = new ZmContact(null);
	contact.initFromPhone(this._actionObject,this.getConfig("defaultContactField"));
	AjxDispatcher.run("GetContactController").show(contact);
};

com_zimbra_scs.prototype._PostRestCall = 
function(calledNumber) {
    calledNumber = this._removeInvalidLetters(calledNumber);
    this._clickToCall(calledNumber);
    return;
};
com_zimbra_scs.prototype._PostRestCall2 = 
function(callingNumber, calledNumber) {
    callingNumber = this._removeInvalidLetters(callingNumber);
    calledNumber = this._removeInvalidLetters(calledNumber);
    this._clickToCall2(callingNumber, calledNumber);
    return;
};

com_zimbra_scs.prototype._showCallDlg = 
function(calledNumber) {
	if (this._CallDialog) {
		this._CallDialog.popup();
		document.getElementById("callingNumber").value = this._getProcessedNumber(calledNumber, this.prefix_remove, this.prefix_add);
		return;
	}
	this._CallDialogView = new DwtComposite(this.getShell());
	this._CallDialogView.getHtmlElement().style.overflow = "auto";
	this._CallDialogView.getHtmlElement().innerHTML = this._createCallView(calledNumber);

	this._CallDialog = this._createDialog({title:"Call", view:this._CallDialogView, standardButtons:[DwtDialog.OK_BUTTON, DwtDialog.CANCEL_BUTTON]});
	this._CallDialog.setButtonListener(DwtDialog.OK_BUTTON, new AjxListener(this, this._okCallingBtnListener));
	this._CallDialog.popup();
};

com_zimbra_scs.prototype._createCallView =
function(calledNumber) {
	var html = [];
	var i = 0;
	html[i++] = "<FORM>";
	html[i++] = "<TABLE>";
	html[i++] = "<TR>";
	html[i++] = "<TD>";
	html[i++] = "<input type='radio' id='FromType1' name='FromType' value='1' checked>using primary phone";
	html[i++] = "</TD></TR><TR>";
	html[i++] = "<TD>";
	html[i++] = "<input type='radio' id='FromType2' name='FromType' value='2'>using the following phone";
	html[i++] = "</TD><TD>";
	html[i++] = "<input id='FromNumber' name='FromNumberName' type='text' value=''/>";
	html[i++] = "</TD>";
	html[i++] = "</TR><br>";
	html[i++] = "</table>";
	html[i++] = "<table>";
	html[i++] = "<TR>";
	html[i++] = "<TD>";
	html[i++] = "Call: ";
	html[i++] = "</TD><TD>";
	html[i++] = "<input id='callingNumber'  type='text' value='" + this._getProcessedNumber(calledNumber, this.prefix_remove, this.prefix_add) + "'/>";
	html[i++] = "</TD>";
	html[i++] = "</TR>";
	html[i++] = "</TABLE>";
	html[i++] = "</FORM>";
	return html.join("");
};

com_zimbra_scs.prototype._okCallingBtnListener =
function() {

	var numbertocall = document.getElementById("callingNumber").value;
	if (!this._checkForAlphaOnlyReg(numbertocall))
	{
		alert("Invalid letters found in number to call! remove them and try again");
		return;
	}

	if (document.getElementById("FromType2").checked)
	{
		var FromNumber = document.getElementById("FromNumber").value;
		if (!this._checkForAlphaOnlyReg(FromNumber))
		{
			alert("Invalid letters found in originating number! remove them and try again");
			return;
		}

		this._PostRestCall2(FromNumber, numbertocall);
	}

	else
	{
		this._PostRestCall(numbertocall);
	}
	this._CallDialog.popdown();
};

com_zimbra_scs.prototype._getProcessedNumber=
function(calledNumber, prefix_remove, prefix_add) 
{
	if (calledNumber.length >= prefix_remove.length)
	{
		if (calledNumber.substr(0, prefix_remove.length) == prefix_remove)
		{
			if (calledNumber.length == prefix_remove.length)
			{
				calledNumber = "";
			}
			else
			{
				var strtokeep = calledNumber.substr(prefix_remove.length);
				calledNumber = strtokeep;
			}
		}
	}

	return this._removeInvalidLetters(prefix_add + calledNumber);
};

com_zimbra_scs.prototype._checkDomain = 
function (nname)
{
	var filter = /^[A-Za-z0-9\-\.]+$/;
	return filter.test(nname);
};	

com_zimbra_scs.prototype._removeInvalidLetters = 
function (strtocheck) {

		var cleanNumber ='';
		var hh;

		for(var j=0; j<strtocheck.length; j++)
		{
		  hh = strtocheck.charAt(j);
		  if((hh >= '0' && hh <= '9') || (hh >= 'a' && hh <= 'z') || (hh >= 'A' && hh <= 'Z'))
		  {
			cleanNumber = cleanNumber + hh;
		  }
		}
		
		return cleanNumber;
};

com_zimbra_scs.prototype._checkForAlphaOnlyReg = 
function (strtocheck) {
	return (/^[0-9a-zA-Z]*$/).test(strtocheck);
};
com_zimbra_scs.prototype._checkForNumberOnlyReg = 
function (strtocheck) {
	return (/^[0-9]*$/).test(strtocheck);
};

com_zimbra_scs.prototype._validateIP = 
function (strtocheck) {
	var filter = /^(([1-9][0-9]{0,2})|0)\.(([1-9][0-9]{0,2})|0)\.(([1-9][0-9]{0,2})|0)\.(([1-9][0-9]{0,2})|0)$/;
	return filter.test(strtocheck);
};


com_zimbra_scs.prototype._showChooseDlg = 
function(ZmObj, isSrcObj) {

	var prefix_remove_loc = this.prefix_remove;
	var prefix_add_loc = this.prefix_add; 

	if (this._ChooseDialog) 
	{
		this._ChooseDialog.popup();

		this._removeAllOptions(document.getElementById("listNumbers"));

		if (isSrcObj)
		{
			if (ZmObj.attr.workPhone)
			{
				this._addOption(document.getElementById("listNumbers"), "work", ZmObj.attr.workPhone);
			}
			if (ZmObj.attr.workPhone2)
			{
				this._addOption(document.getElementById("listNumbers"), "work2", ZmObj.attr.workPhone2);
			}
			if (ZmObj.attr.homePhone)
			{
				this._addOption(document.getElementById("listNumbers"),  "home", ZmObj.attr.homePhone);
			}
			if (ZmObj.attr.homePhone2)
			{
				this._addOption(document.getElementById("listNumbers"),  "home2", ZmObj.attr.homePhone2);
			}
			if (ZmObj.attr.mobilePhone)
			{
				this._addOption(document.getElementById("listNumbers"),  "mobile", ZmObj.attr.mobilePhone);
			}
			if (ZmObj.attr.otherPhone)
			{
				this._addOption(document.getElementById("listNumbers"),  "other", ZmObj.attr.otherPhone);
			}
		}

		else
		{
			if (ZmObj.workPhone)
			{
				this._addOption(document.getElementById("listNumbers"), "work", ZmObj.workPhone);
			}
			if (ZmObj.homePhone)
			{
				this._addOption(document.getElementById("listNumbers"),  "home", ZmObj.homePhone);
			}
			if (ZmObj.workPhone2)
			{
				this._addOption(document.getElementById("listNumbers"), "work2", ZmObj.workPhone2);
			}
			if (ZmObj.homePhone2)
			{
				this._addOption(document.getElementById("listNumbers"),  "home2", ZmObj.homePhone2);
			}
			if (ZmObj.mobilePhone)
			{
				this._addOption(document.getElementById("listNumbers"),  "mobile", ZmObj.mobilePhone);
			}
			if (ZmObj.otherPhone)
			{
				this._addOption(document.getElementById("listNumbers"),  "other", ZmObj.otherPhone);
			}
		}

		document.getElementById("listNumbers").onchange = function()
		{ 
			var calledNumber = document.getElementById("listNumbers").value;
			if (calledNumber.length >= prefix_remove_loc.length)
			{
				if (calledNumber.substr(0, prefix_remove_loc.length) == prefix_remove_loc)
				{
					if (calledNumber.length == prefix_remove_loc.length)
					{
						calledNumber = "";
					}
					else
					{
						var strtokeep = calledNumber.substr(prefix_remove_loc.length);
						calledNumber = strtokeep;
					}
				}
			}
		
			var preprocessedNumber = prefix_add_loc + calledNumber;

			var cleanNumber ='';
			var hh;

			for(var j=0; j<preprocessedNumber.length; j++)
			{
			  hh = preprocessedNumber.charAt(j);
			  if(hh >= '0' && hh <= '9')
			  {
				cleanNumber = cleanNumber + hh;
			  }
			}
		
	  		document.getElementById("numbertocall").value = cleanNumber;
		};

		document.getElementById("numbertocall").value = this._getProcessedNumber(document.getElementById("listNumbers").value, this.prefix_remove, this.prefix_add);

		return;
	}
	this._ChooseDialogView = new DwtComposite(this.getShell());
	this._ChooseDialogView.getHtmlElement().style.overflow = "auto";
	this._ChooseDialogView.getHtmlElement().innerHTML = this._createChooseView(ZmObj, isSrcObj);

	this._ChooseDialog = this._createDialog({title:"Call", view:this._ChooseDialogView, standardButtons:[DwtDialog.OK_BUTTON, DwtDialog.CANCEL_BUTTON]});
	this._ChooseDialog.setButtonListener(DwtDialog.OK_BUTTON, new AjxListener(this, this._okChooseBtnListener));
	this._ChooseDialog.popup();

	document.getElementById("listNumbers").onchange = function()
	{ 
		var calledNumber = document.getElementById("listNumbers").value;
		if (calledNumber.length >= prefix_remove_loc.length)
		{
			if (calledNumber.substr(0, prefix_remove_loc.length) == prefix_remove_loc)
			{
				if (calledNumber.length == prefix_remove_loc.length)
				{
					calledNumber = prefix_add_loc;
				}
				else
				{
					var strtokeep = calledNumber.substr(prefix_remove_loc.length);
					calledNumber = prefix_add_loc + strtokeep;
				}
			}
		}

		var cleanNumber ='';
		var hh;

		for(var j=0; j<calledNumber.length; j++)
		{
		  hh = calledNumber.charAt(j);
		  if(hh >= '0' && hh <= '9')
		  {
			cleanNumber = cleanNumber + hh;
		  }
		}

	  	document.getElementById("numbertocall").value = cleanNumber;
	};
	
	document.getElementById("numbertocall").value = this._getProcessedNumber(document.getElementById("listNumbers").value, this.prefix_remove, this.prefix_add);
};

com_zimbra_scs.prototype._removeAllOptions = function (selectbox)
{
	var i;
	for(i = selectbox.options.length-1;i>=0;i--)
	{
		selectbox.remove(i);
	}
};

com_zimbra_scs.prototype._addOption = function (selectbox,text,value)
{
var optn = document.createElement("OPTION");
optn.text = text;
optn.value = value;
selectbox.options.add(optn);
};


com_zimbra_scs.prototype._createChooseView =
function(ZmObject, isSrcObj) 
{
	var html = [];
	var i = 0;

	html[i++] = "<TABLE>";
	html[i++] = "<TR>";
	html[i++] = "<TD>";
	html[i++] = "<input type='radio' id='FromType1_C' name='FromType_C' value='1' checked>using primary phone";
	html[i++] = "</TD></TR><TR>";
	html[i++] = "<TD>";
	html[i++] = "<input type='radio' id='FromType2_C' name='FromType_C' value='2'>using the following phone";
	html[i++] = "</TD><TD>";
	html[i++] = "<input id='FromNumber_C' name='FromNumber_CName' type='text' value=''/>";
	html[i++] = "</TD>";
	html[i++] = "</TR>";
	html[i++] = "</TABLE><br>";
	html[i++] = "<TABLE>";
	html[i++] = "<TR>";
	html[i++] = "<TD>Call:</TD>";
	html[i++] = "<TD>";

	html[i++] = "<select id='listNumbers'>";
	
	if (isSrcObj)
	{
		if (ZmObject.attr.workPhone)
		{
			html[i++] = "<option value='"+ ZmObject.attr.workPhone+ "'>work</option>";
		}
		if (ZmObject.attr.homePhone)
		{
			html[i++] = "<option value='"+ ZmObject.attr.homePhone+ "'>home</option>";
		}
		if (ZmObject.attr.workPhone2)
		{
			html[i++] = "<option value='"+ ZmObject.attr.workPhone2+ "'>work2</option>";
		}
		if (ZmObject.attr.homePhone2)
		{
			html[i++] = "<option value='"+ ZmObject.attr.homePhone2+ "'>home2</option>";
		}
		if (ZmObject.attr.mobilePhone)
		{
			html[i++] = "<option value='"+ ZmObject.attr.mobilePhone+ "'>mobile</option>";
		}
		if (ZmObject.attr.otherPhone)
		{
			html[i++] = "<option value='"+ ZmObject.attr.otherPhone+ "'>other</option>";
		}
	}
	else
	{
	
		if (ZmObject.workPhone)
		{
			html[i++] = "<option value='"+ ZmObject.workPhone+ "'>work</option>";
		}
		if (ZmObject.homePhone)
		{
			html[i++] = "<option value='"+ ZmObject.homePhone+ "'>home</option>";
		}
		if (ZmObject.workPhone2)
		{
			html[i++] = "<option value='"+ ZmObject.workPhone2+ "'>work2</option>";
		}
		if (ZmObject.homePhone2)
		{
			html[i++] = "<option value='"+ ZmObject.homePhone2+ "'>home2</option>";
		}
		if (ZmObject.mobilePhone)
		{
			html[i++] = "<option value='"+ ZmObject.mobilePhone+ "'>mobile</option>";
		}
		if (ZmObject.otherPhone)
		{
			html[i++] = "<option value='"+ ZmObject.otherPhone+ "'>other</option>";
		}
	}

	html[i++] = "</select>";
	html[i++] = "</TD>";
	html[i++] = "<TD>";
	html[i++] = "<input id='numbertocall'  type='text'/>";
	html[i++] = "</TD>";
	html[i++] = "</TR>";
	html[i++] = "</TABLE>";

	return html.join("");
};

com_zimbra_scs.prototype._okChooseBtnListener =
function() {

	var numbertocall = document.getElementById("numbertocall").value;
	if (!this._checkForAlphaOnlyReg(numbertocall))
	{
		alert("Invalid letters found! remove them and try again");
		return;
	}

	if (document.getElementById("FromType2_C").checked)
	{
		var FromNumber = document.getElementById("FromNumber_C").value;
		if (!this._checkForAlphaOnlyReg(FromNumber))
		{
			alert("Invalid letters found in originating number! remove them and try again");
			return;
		}

		this._PostRestCall2(FromNumber, numbertocall);
	}

	else
	{

		this._PostRestCall(numbertocall);
	}
	this._ChooseDialog.popdown();
};

com_zimbra_scs.prototype._waitForContactToLoadAndProcess = function() {
	this._contactList = AjxDispatcher.run("GetContacts");
	if (!this._contactList)
	{
		return;
	}

	this.__currNumContacts = this._contactList.getArray().length;
	if (this._totalWaitCnt < 2 || this._noOpLoopCnt < 3) {//minimum 2 cycles post currentCnt==oldCnt
		if (this.__oldNumContacts == this.__currNumContact) {
			this._noOpLoopCnt++;
		}
		this._totalWaitCnt++;
		this.__oldNumContacts = this.__currNumContact;
		setTimeout(AjxCallback.simpleClosure(this._waitForContactToLoadAndProcess, this), 3000);
	} else {
		var carray = this._contactList.getArray();
		for (var i = 0; i < carray.length; i ++)
		{
			alert(carray[i]._attrs.homePhone);
		}

		return;

	}
};

com_zimbra_scs.prototype._queryPresence =
function(sipid)
{
	var url = this.getResource("getPresence.jsp");
	var params= ["who=" + AjxStringUtil.urlComponentEncode(sipid),
			"ofserverip=" + AjxStringUtil.urlEncode(this.scs_server),
			"ofport=" + AjxStringUtil.urlEncode(this.presence_port)
			].join ("&");
	var resp = AjxRpc.invoke(null, url+"?"+params, null, null, true);

	eval( "var jsonObj = " + resp.text);

	return jsonObj;
};

com_zimbra_scs.prototype._normalizeContacts =
function() {
	this.isAddressbookInitialized = true;	
	return;

};

com_zimbra_scs.prototype._initializeAddressBook = function() {
	this.isAddressbookInitialized = false;
	var  postCallback = new AjxCallback(this, this._normalizeContacts);
	this.loadAllContacts(postCallback);
};

com_zimbra_scs.prototype.loadAllContacts = function(postCallBack) {
	this.__oldNumContacts = 0;
	this._noOpLoopCnt = 0;
	this._totalWaitCnt = 0;

	if(this._contactsAreLoaded) {//2nd time onwards..
		if(postCallback) 
		{
			postCallback.run(this);
			return;
		}
	}
	var transitions = [ ZmToast.FADE_IN, ZmToast.PAUSE,  ZmToast.PAUSE,  ZmToast.PAUSE,  ZmToast.PAUSE,  ZmToast.FADE_OUT ];
	appCtxt.getAppController().setStatusMsg("Please wait, scanning Address Book(it might take up to a minute)..", ZmStatusView.LEVEL_INFO, null, transitions);
	this._contactsAreLoaded = false;
	this._waitForContactToLoadAndProcess(postCallBack);
	this._contactsAreLoaded = true;
};
com_zimbra_scs.prototype._waitForContactToLoadAndProcess = function(postCallback) {
	this._contactList = AjxDispatcher.run("GetContacts");
	if (!this._contactList)
	{
		return;
	}

	this.__currNumContacts = this._contactList.getArray().length;
	if (this._totalWaitCnt < 2 || this._noOpLoopCnt < 3) {//minimum 2 cycles post currentCnt==oldCnt
		if (this.__oldNumContacts == this.__currNumContact) {
			this._noOpLoopCnt++;
		}
		this._totalWaitCnt++;
		this.__oldNumContacts = this.__currNumContact;
		setTimeout(AjxCallback.simpleClosure(this._waitForContactToLoadAndProcess, this, postCallback), 5000);
	} else {//process..
		if(postCallback) {
			postCallback.run(this);
		}
	}
};

com_zimbra_scs.prototype._getContactByPhone =
function(phoneNumber) {
	if (!this._contactList)
	{
		alert(" AddressBook is not intialized!")
		return;
	}

	if (!this.isAddressbookInitialized)
	{
		alert(" AddressBook intialization is in process!")
		return;
	}

	var _tmpArry = this._contactList.getArray();

	for (var j = 0; j < _tmpArry.length; j++) 
	{
		var currentContact = _tmpArry[j];
		var attr = currentContact.attr ? currentContact.attr : currentContact._attrs;
		try 
		{
			currentContact._firstName = (attr.firstName) ? (attr.firstName).toLowerCase() : "-";
			currentContact._lastName = (attr.lastName) ? (attr.lastName).toLowerCase() : "-";
			currentContact._otherIM = (attr.otherPhone) ? attr.otherPhone : "-";


			currentContact._workPhone = (attr.workPhone) ? attr.workPhone : "-";
			if (currentContact._workPhone == phoneNumber) {
				return currentContact;
			}

			currentContact._workPhone2 = (attr.workPhone2) ? attr.workPhone2 : "-";
			if (currentContact._workPhone2 == phoneNumber) {
				return currentContact;
			}

			currentContact._companyPhone = (attr.companyPhone) ? attr.companyPhone : "-";
			if (currentContact._companyPhone == phoneNumber) {
				return currentContact;
			}

			currentContact._homePhone = (attr.homePhone) ? attr.homePhone : "-";
			if (currentContact._homePhone == phoneNumber) {
				return currentContact;
			}

			currentContact._homePhone2 = (attr.homePhone2) ? attr.homePhone2 : "-";
			if (currentContact._homePhone2 == phoneNumber) {
				return currentContact;
			}

			currentContact._mobilePhone = (attr.mobilePhone) ? attr.mobilePhone : "-";
			if (currentContact._mobilePhone == phoneNumber) {
				return currentContact;
			}

			currentContact._otherPhone = (attr.otherPhone) ? attr.otherPhone : "-";
			if (currentContact._otherPhone == phoneNumber) {
				return currentContact;
			}

		} catch(e) {
		}

	}
		
	return null;
};

com_zimbra_scs.prototype._saveConf = 
function()
{
	var url = this.getResource("saveConf.jsp");
	var params= ["ofserverip=" + AjxStringUtil.urlComponentEncode(this.scs_server),
			"ofport=" + AjxStringUtil.urlEncode(this.presence_port),
			"sslenabled=" + AjxStringUtil.urlEncode(this.scs_sslenabled == 1? "1" :"0") ,
			"port=" + AjxStringUtil.urlEncode(this.scs_port),
			"user=" + AjxStringUtil.urlEncode(this.scs_user),
			"password=" + AjxStringUtil.urlEncode(this.scs_password),
			"prefixadd=" + AjxStringUtil.urlEncode(this.prefix_add),
			"prefixremove=" + AjxStringUtil.urlEncode(this.prefix_remove)
			].join ("&");
	var resp = AjxRpc.invoke(null, url+"?"+params, null, null, true);
};
