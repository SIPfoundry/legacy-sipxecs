************** README ***************

version: 1.0

Summary: Provide click to call/presence capability within Zimbra

Version supported : Zimbra 6.0 

The plug in consists of two zimlets.  One is phone number based zimlet (com_zimbra_scs) which also contains configuration; the other is email based zimlet (on top of existing com_zimbra_email zimlet)  which relies on the com_zimbra_scs zimlet for configuration so it needs to be deployed together with the phone number based zimlet.
Both zimlets will be posted on Zimbra Zimlet gallery as well.
- com_zimbra_scs zimlet provides following functionality
-Click to call
Make call from Zimbra using SipX/SCS by
1) Click a phone number in email message or a contact.s phone number field.
3) Drag and Drop an email to the SCS zimlet node to call the sender
5) Drag and Drop an contact to the SCS zimlet node to pick a number to call.
6) Drag and Drop an appointment to start a meeting (the meeting location has to be like "SCS@BN <conference number> [passcode xxxx]" , the [passcode] part is optional.
7) Click the SCS zimlet node and users provide a number to call.
8) To configure, right click on the "SCS" node in the zimlet list. 
- Presence
Users could check a contact presence by
1)Mouse over a phone number 
2)right click a phone number to check the presence detail.
----------------------------------------------------------------- 
On top its existing functionality, email based zimlet provides following additional functionality, 
- Click to call 
Make call to a contact from Zimbra using Sipx/SCS by
1) Click an email address  in email message or in a email's from/to/cc/bcc etc field. 
2) Click an email address  in a contact.s email field. 
-Presence
Users could check a contact's presence by
1) Mouse over an email address 
2) Right click an email address to check the presence detail


- Limitation and Work around
1) Due to performance concern, the address book is initialized and cached locally in browser during log in process. Modification to the address book will not take into effect until users re-login. (log out/log in again).
2) Switch from NON-SSL to SSL requires browser restart due to the NON-SSL mode password caching. If restart does not help, password caching needs to be cleaned up from browser. how to clear password cache depdends on Browser implementation.
3) In Non-SSL mode, if user password/pin number is input incorrectly. password caching need to be cleaned up in order to see the password prompt window again.

