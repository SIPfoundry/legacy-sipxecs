/opt/zimbra/bin/zmzimletctl undeploy com_zimbra_email_plus
zip com_zimbra_email_plus.zip *
cp ./com_zimbra_email_plus.zip /opt/zimbra/zimlets
cd /opt/zimbra/zimlets
/opt/zimbra/bin/zmzimletctl deploy com_zimbra_email_plus.zip
tail -f /opt/zimbra/log/mailbox.log
