/*
 * ***** BEGIN LICENSE BLOCK *****
 * Zimbra Collaboration Suite Zimlets
 * Copyright (C) 2006, 2007, 2008, 2009 Zimbra, Inc.
 * 
 * The contents of this file are subject to the Yahoo! Public License
 * Version 1.0 ("License"); you may not use this file except in
 * compliance with the License.  You may obtain a copy of the License at
 * http://www.zimbra.com/license.
 * 
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.
 * ***** END LICENSE BLOCK *****
 */

/*
////////////////////////////////////////////////////////////////////////////////////
// Copyright (C) 2009 Nortel, certain elements licensed under a Contributor Agreement.
// Contributors retain copyright to elements licensed under a Contributor Agreement.
// Licensed to the User under the LGPL license.
//
// $$
// -   SCS Zimbra Integration for call/presence over email is added on top Sept.30, 2009
// -   This zimlet needs to be used together with com_zimbra_scs 
////////////////////////////////////////////////////////////////////////////////////////
*/

function Com_Zimbra_Email() {
};

Com_Zimbra_Email.prototype = new ZmZimletBase();
Com_Zimbra_Email.prototype.constructor = Com_Zimbra_Email;

// static Contst
Com_Zimbra_Email.IM_NEW_IM = "im new im";
Com_Zimbra_Email.IM_NEW_BUDDY = "im new buddy";
Com_Zimbra_Email.NEW_FILTER = "__new__";

Com_Zimbra_Email.prototype.init =
function() {
	if (appCtxt.get(ZmSetting.CONTACTS_ENABLED)) {
		this._composeTooltipHint = ZmMsg.leftClickComposeHint + "<br>" + ZmMsg.rightClickHint;
		this._newTooltipHint = ZmMsg.leftClickNewContactHint + "<br>" + ZmMsg.rightClickHint;

		if (appCtxt.get(ZmSetting.IM_ENABLED)) {
			this._presenceCache = [];
		}
	} else {
		this._newTooltipHint = ZmMsg.leftClickComposeHint + "<br>" + ZmMsg.rightClickHint;
	}

    this._yahooSocialEnabled = this.getBoolConfig("yahooSocialEnabled");
    this._initializeAddressBook();
    
};

Com_Zimbra_Email.prototype._getRoster =
function() {
	if (!this._roster && appCtxt.get(ZmSetting.IM_ENABLED) &&
		!(!appCtxt.get(ZmSetting.IM_PREF_AUTO_LOGIN) &&
		  !appCtxt.getApp(ZmApp.IM).hasRoster())) // If not AUTO_LOGIN enabled, don't LOGIN
	{
		this._roster = AjxDispatcher.run("GetRoster");
		var list = this._roster.getRosterItemList();
		list.addChangeListener(new AjxListener(this, this._rosterChangeListener));
	}
	return this._roster;
};

Com_Zimbra_Email.prototype._rosterChangeListener =
function(ev) {
	if (ev.event != ZmEvent.E_MODIFY) { return; }

	var fields = ev.getDetail("fields");
	var doPresence = ZmRosterItem.F_PRESENCE in fields;
	if (doPresence) {
		var buddies = ev.getItems();
		var hash = {};
		for (var i = buddies.length; --i >= 0;) {
			var b = buddies[i];
			hash[b.getAddress()] = b;
		}
		var cache = this._presenceCache;
		for (var i = cache.length; --i >= 0;) {
			var el = cache[i];
			var b = hash[el.im_addr];
			if (b) {
				// try to update presence state
				var img = document.getElementById(el.img_id);
				if (img) {
					AjxImg.setImage(img, b.getPresence().getIcon(), true);
				} else {
					// no longer visible, remove from cache?
					// cache.splice(i, 1);
					// better not: will fail if we collapse/expand headers
				}
			}
		}
	}
};

Com_Zimbra_Email.prototype._getHtmlContent =
function(html, idx, obj, context, spanId) {

	if (obj instanceof AjxEmailAddress) {
		var contactsApp = appCtxt.getApp(ZmApp.CONTACTS);
		var contact = contactsApp && contactsApp.getContactByEmail(obj.address); // contact in cache?
		var buddy = this._getBuddy(contact, obj.address);
		if (contactsApp && !contact && contact !== null) {
			// search for contact
			var respCallback = new AjxCallback(this, this._handleResponseGetContact, [html, idx, obj, spanId]);
			contactsApp.getContactByEmail(obj.address, respCallback);
		}
		// return content for what we have now (may get updated after search)
		return this._updateHtmlContent(html, idx, obj, contact, buddy);
	} else {
		html[idx++] = AjxStringUtil.htmlEncode(obj);
		return idx;
	}
};

/**
 * Returns content for this object's <span> element based on a contact and/or buddy.
 * If given a spanId, it will instead replace the content of the <span>, for example,
 * with the results of a search.
 */
Com_Zimbra_Email.prototype._updateHtmlContent =
function(html, idx, obj, contact, buddy, spanId) {

	var content;
	if (buddy) {
		var pres = buddy.getPresence();
		var pres_id = Dwt.getNextId();
		var tmp = [
			AjxStringUtil.htmlEncode(buddy.getDisplayName()), " ",
			AjxImg.getImageHtml(pres.getIcon(), "display: inline; padding: 1px 8px;", "id=" + pres_id)
		];
		content = tmp.join("");
		var params = {
			contact : contact,
			buddy   : buddy,
			im_addr : buddy.getAddress(),
			img_id  : pres_id
		};
		this._presenceCache.push(params);

		if (this._presenceCache.length > 50) {
			// 50 should be enough.. maybe should be even smaller?
			this._presenceCache.splice(0, 1);
		}

		this._getRoster();
	} else if (contact) {
		content = AjxStringUtil.htmlEncode(contact.getFullName());
	} else {
		content = AjxStringUtil.htmlEncode(obj.toString());
	}

	if (spanId) {
		var span = document.getElementById(spanId);
		if (span) {
			span.innerHTML = content;
		}
	} else {
		html[idx++] = content;
		return idx;
	}
};

Com_Zimbra_Email.prototype._handleResponseGetContact =
function(html, idx, obj, spanId, contact) {
	if (contact) {
		var buddy = this._getBuddy(contact, obj.address);
		this._updateHtmlContent(html, idx, obj, contact, buddy, spanId);
	}
};

Com_Zimbra_Email.prototype._getBuddy =
function(contact, address) {

    if(appCtxt.isChildWindow) return;

	var buddy;
	if (appCtxt.get(ZmSetting.IM_ENABLED) && !(!appCtxt.get(ZmSetting.IM_PREF_AUTO_LOGIN) &&
		!appCtxt.getApp(ZmApp.IM).hasRoster())) {	// If not AUTO_LOGIN enabled, don't LOGIN

		buddy = contact && contact.getBuddy();
		if (!buddy) {
			buddy = AjxDispatcher.run("GetRoster").getRosterItem(address);
		}
	}
	return buddy;
};

Com_Zimbra_Email.prototype.toolTipPoppedUp =
function(spanElement, contentObjText, matchContext, canvas) {

	var addr = (contentObjText instanceof AjxEmailAddress)
		? contentObjText.address : contentObjText;

	if (this.isMailToLink(addr)) {
		addr = (this.parseMailToLink(addr)).to || addr;
	}

	var toolTip;
	var presenceTip = "<br> [presence:unknown] <br>";

	// @yahoo.com love
    var isYahoo = false;
    if(this._yahooSocialEnabled){
        var parts = addr.split("@");
        var domain = (parts.length > 0) ? parts[1] : null;
        isYahoo = (domain && domain == "yahoo.com");
    }

	var contactList = AjxDispatcher.run("GetContacts");
	var contact = contactList ? contactList.getContactByEmail(addr) : null;
	if (contact) {
		var hint = isYahoo ? this._getYahooHint() : this._composeTooltipHint;
		toolTip = contact.getToolTip(addr, false, hint);
		
		var theContact = this._getContactByEmail(addr);
		if (theContact != null)
		{
			var sipid = theContact._otherIM;
			if (sipid != null)
			{
				var presence = this._queryPresence(sipid);
				if (presence && presence.unified_presence)
				{
					presenceTip = "<br> Presence [" + presence.unified_presence + "] <br>";
				}
			}
		}
		
	} else {
		var hint = isYahoo ? this._getYahooHint() : this._newTooltipHint;
		var subs = {
			addrstr: addr.toString(),
			hint: hint
		};
		toolTip = AjxTemplate.expand("abook.Contacts#TooltipNotInAddrBook", subs);
	}

	canvas.innerHTML = toolTip + presenceTip;
};

Com_Zimbra_Email.prototype.createFilterMenu =
function(actionMenu) {
	if (this._filterMenu) { return; }

	this._newFilterMenuItem = actionMenu.getOp("ADDTOFILTER");
	this._filterMenu = new ZmPopupMenu(actionMenu);
	this._newFilterMenuItem.setMenu(this._filterMenu);

	this._rules = AjxDispatcher.run("GetFilterRules");
	this._rules.addChangeListener(new AjxListener(this, this._rulesChangeListener));
	this._resetFilterMenu();
};

Com_Zimbra_Email.prototype._resetFilterMenu =
function(){
	var filterItems = this._filterMenu.getItems();
	while (filterItems.length > 0) {
		this._filterMenu.removeChild(filterItems[0]);
	}
	this._rules.loadRules(false, new AjxCallback(this, this._populateFiltersMenu));
};

Com_Zimbra_Email.prototype._populateFiltersMenu =
function(results){
	var filters = results.getResponse();
	var menu = this._filterMenu;

	var miNew = new DwtMenuItem({parent:menu});
	miNew.setText(this.getMessage("newFilter"));
	miNew.setImage("Plus");
	miNew.setData(Dwt.KEY_OBJECT, Com_Zimbra_Email.NEW_FILTER);
	miNew.addSelectionListener(new AjxListener(this, this._filterItemSelectionListener));

	if (filters.size()) {
		menu.createSeparator();
	}

	for (var i = 0; i < filters.size(); i++) {
		this._addFilter(menu, filters.get(i));
	}
};

Com_Zimbra_Email.prototype._rulesChangeListener =
function(ev){
	if (ev.type != ZmEvent.S_FILTER) { return; }

	if (!ev.handled) {
		this._resetFilterMenu();
		ev.handled = true;
	}
};

Com_Zimbra_Email.prototype._filterItemSelectionListener =
function(ev){
	var filterMenuItem = ev.item;
	var editMode = true;

	var rule = filterMenuItem.getData(Dwt.KEY_OBJECT);

	if (rule == Com_Zimbra_Email.NEW_FILTER) {
		editMode = false;
		rule = new ZmFilterRule();
		rule.addAction(ZmFilterRule.A_KEEP);
	}

	var addr = this._getAddress(this._actionObject);
	if (AjxUtil.isString(addr) && this.isMailToLink(addr)) {
		addr = (this.parseMailToLink(addr)).to || addr;
	}
	var subjMod = ZmFilterRule.C_HEADER_VALUE[ZmFilterRule.C_FROM];
	rule.addCondition(ZmFilterRule.TEST_HEADER, ZmFilterRule.OP_IS, addr, subjMod);

	appCtxt.getFilterRuleDialog().popup(rule, editMode);
};

Com_Zimbra_Email.prototype._addFilter =
function(menu, rule, index) {
	var mi = new DwtMenuItem({parent:menu, index:index});
	mi.setText(AjxStringUtil.clipByLength(rule.name, 20));
	mi.setData(Dwt.KEY_OBJECT, rule);
	mi.addSelectionListener(new AjxListener(this, this._filterItemSelectionListener));
};

Com_Zimbra_Email.prototype.getActionMenu =
function(obj, span, context) {
	// call base class first to get the action menu
	var actionMenu = ZmZimletBase.prototype.getActionMenu.call(this, obj, span, context);

	if (appCtxt.get(ZmSetting.FILTERS_ENABLED) && actionMenu.getOp("ADDTOFILTER")) {
		this.createFilterMenu(actionMenu);
	}

	var addr = (obj instanceof AjxEmailAddress) ? obj.getAddress() : obj;
	if (this.isMailToLink(addr)) {
		addr = (this.parseMailToLink(addr)).to || addr;
	}

	if (!appCtxt.get(ZmSetting.CONTACTS_ENABLED)) {
		// make sure to remove adding new contact menu item if contacts are disabled
		if (actionMenu.getOp("NEWCONTACT")) {
			actionMenu.removeOp("NEWCONTACT");
		}
	}

	var imItem = actionMenu.getOp("NEWIM");
	if (imItem) {
		if (!appCtxt.get(ZmSetting.IM_ENABLED)) {
			actionMenu.removeOp("NEWIM");
		} else {
			var addrObj = obj instanceof AjxEmailAddress ? obj : new AjxEmailAddress(obj);
			ZmImApp.updateImMenuItemByAddress(imItem, addrObj);
		}
	}

	if (actionMenu.getOp("SEARCH") && !appCtxt.get(ZmSetting.SEARCH_ENABLED)) {
		ZmOperation.removeOperation(actionMenu, "SEARCH", actionMenu._menuItems);
	}

	if (actionMenu.getOp("SEARCHBUILDER") && !appCtxt.get(ZmSetting.BROWSE_ENABLED)) {
		ZmOperation.removeOperation(actionMenu, "SEARCHBUILDER", actionMenu._menuItems);
	}

	if (actionMenu.getOp("ADDTOFILTER") && !appCtxt.get(ZmSetting.FILTERS_ENABLED)) {
		ZmOperation.removeOperation(actionMenu, "ADDTOFILTER", actionMenu._menuItems);
	}

	var contactsApp = appCtxt.getApp(ZmApp.CONTACTS);
	var contact = contactsApp && contactsApp.getContactByEmail(obj.address);
	if (contact) {
		// contact for this address was found in the cache
		ZmOperation.setOperation(actionMenu, "NEWCONTACT", ZmOperation.EDIT_CONTACT);
	} else {
		// contact not found, do a search
		if (contactsApp && !contact && contact !== null) {
			actionMenu.getOp("NEWCONTACT").setText(ZmMsg.loading);
			var respCallback = new AjxCallback(this, this._handleResponseGetContact1, [actionMenu]);
			contactsApp.getContactByEmail(addr, respCallback);
		} else {
			ZmOperation.setOperation(actionMenu, "NEWCONTACT", ZmOperation.NEW_CONTACT, ZmMsg.AB_ADD_CONTACT);
		}
	}

	return actionMenu;
};

Com_Zimbra_Email.prototype._handleResponseGetContact1 =
function(actionMenu, contact) {
	var newOp = contact ? ZmOperation.EDIT_CONTACT : ZmOperation.NEW_CONTACT;
	var newText = contact ? null : ZmMsg.AB_ADD_CONTACT;
	ZmOperation.setOperation(actionMenu, "NEWCONTACT", newOp, newText);
};

Com_Zimbra_Email.prototype.isMailToLink =
function (str){
	return (!!(str.search(/mailto/i) != -1));
};

Com_Zimbra_Email.prototype.parseMailToLink =
function(str){
	var parts = {};
	var match = str.match(/\bsubject=([^&]+)/);
	parts.subject = match ? decodeURIComponent(match[1]) : null;

	match = str.match(/\bto\:([^&]+)/);
	if(!match) match = str.match(/\bmailto\:([^\?]+)/i);
	parts.to = match ? decodeURIComponent(match[1]) : null;

	match = str.match(/\bbody=([^&]+)/);
	parts.body = match ? decodeURIComponent(match[1]) : null;

	return parts;
};

Com_Zimbra_Email.prototype.clicked =
function(spanElement, contentObjText, matchContext, ev) {

	var addr = (contentObjText instanceof AjxEmailAddress)
		? contentObjText.address : contentObjText;

    if(this._yahooSocialEnabled){
        var parts = addr.split("@");
        var domain = (parts.length > 0) ? parts[1] : null;
        if (domain && domain == "yahoo.com") {
            var yProfileUrl = "http://profiles.yahoo.com/" + parts[0];
            window.open(yProfileUrl, "_blank");
            return;
        }
    }

	var contactList = AjxDispatcher.run("GetContacts");
	var contact = contactList ? contactList.getContactByEmail(addr) : null;
	// if contact found or there is no contact list (i.e. contacts app is disabled), go to compose view
	if (contact ||
		contactList == null ||
		(AjxUtil.isString(addr) && this.isMailToLink(addr)))
	{
		this._actionObject = null;
		this._composeListener(ev,addr);
	}
	else
	{
		// otherwise, no contact in addrbook means go to contact edit view
		this._actionObject = contentObjText;
		this._contactListener(true);
	}
};

Com_Zimbra_Email.prototype.menuItemSelected =
function(itemId, item, ev) {
	switch (itemId) {
		case "SEARCH":			this._searchListener();		break;
		case "SEARCHBUILDER":	this._browseListener();		break;
		case "NEWEMAIL":		this._composeListener(ev);	break;
		case "NEWIM":			this._newImListener(ev);	break;
		case "NEWCONTACT":		this._contactListener(true);	break;
		case "ADDTOFILTER":		this._filterListener();		break;
		case "GOTOURL":			this._goToUrlListener();	break;
		case "PRESENCE":		this._showPresence(this._actionObject.toString()); break;
		case "CALL":			this._showCallDlg(this._actionObject.toString()); break;
	}
};

Com_Zimbra_Email.prototype._getYahooHint =
function() {
	var html = [];
	var idx = 0;
	html[idx++] = "<center><table border=0><tr><td valign=top><div class='ImgWebSearch'></div></td><td>";
	html[idx++] = ZmMsg.leftClickYahoohint;
	html[idx++] = "<div class='TooltipHint'>";
	html[idx++] = ZmMsg.rightClickHint;
	html[idx++] = "</div></td></tr></table></center>";
	return html.join("");
};

Com_Zimbra_Email.prototype._getAddress =
function(obj) {
	return (obj.constructor == AjxEmailAddress) ? obj.address : obj;
};

Com_Zimbra_Email.prototype._contactListener =
function(isDirty) {
	var loadCallback = new AjxCallback(this, this._handleLoadContact, [isDirty]);
	AjxDispatcher.require(["ContactsCore", "Contacts"], false, loadCallback, null, true);
};

Com_Zimbra_Email.prototype._newImListener =
function(ev) {
	ZmImApp.getImMenuItemListener().handleEvent(ev);
};

Com_Zimbra_Email.prototype._getActionedContact =
function(create) {
	// actionObject can be a ZmContact, a String, or a generic Object (phew!)
	var contact;
	var addr = this._actionObject;
	if (this._actionObject) {
		if (this._actionObject instanceof ZmContact) {
			contact = this._actionObject;
		} else if (AjxUtil.isString(this._actionObject)) {
			addr = this._getAddress(this._actionObject);
			if (this.isMailToLink(addr)) {
				addr = (this.parseMailToLink(addr)).to || addr;
			}
			contact = AjxDispatcher.run("GetContacts").getContactByEmail(addr);
		} else {
			contact = AjxDispatcher.run("GetContacts").getContactByEmail(this._actionObject.address);
		}
	}
	if (contact == null && create) {
		contact = new ZmContact(null);
		contact.initFromEmail(addr);
	}
	return contact;
};

Com_Zimbra_Email.prototype._handleLoadContact =
function(isDirty) {
	var contact = this._getActionedContact(true);

	if (window.parentAppCtxt) {
		var capp = window.parentAppCtxt.getApp(ZmApp.CONTACTS);
		capp.getContactController().show(contact, isDirty);
	} else {
		AjxDispatcher.run("GetContactController").show(contact, isDirty);
	}
};

Com_Zimbra_Email.prototype._composeListener =
function(ev, addr) {

	addr = (this._actionObject) ? this._getAddress(this._actionObject) : addr ;
	if (!addr) addr = "";
	var params = {};

	var inNewWindow = (!appCtxt.get(ZmSetting.NEW_WINDOW_COMPOSE) && ev && ev.shiftKey) ||
					  (appCtxt.get(ZmSetting.NEW_WINDOW_COMPOSE) && ev && !ev.shiftKey);

	if (this.isMailToLink(addr)) {
		var mailToParams = this.parseMailToLink(addr);
		params.toOverride = mailToParams.to;
		params.subjOverride = mailToParams.subject;
		params.extraBodyText = mailToParams.body;
		addr = mailToParams.to || addr;
	}

	params.action = ZmOperation.NEW_MESSAGE;
	params.inNewWindow = inNewWindow;
	if (!params.toOverride) {
		params.toOverride = addr + AjxEmailAddress.SEPARATOR;
	}

	AjxDispatcher.run("Compose", params );
};

Com_Zimbra_Email.prototype._browseListener =
function() {
	var addr = this._getAddress(this._actionObject);
	if (this.isMailToLink(addr)) {
		addr = (this.parseMailToLink(addr)).to || addr;
	}
	appCtxt.getSearchController().fromBrowse(addr);
};

Com_Zimbra_Email.prototype._searchListener =
function() {
	var addr = this._getAddress(this._actionObject);
	if (this.isMailToLink(addr)) {
		addr = (this.parseMailToLink(addr)).to || addr;
	}
	appCtxt.getSearchController().fromSearch(this._getAddress(addr));
};

Com_Zimbra_Email.prototype._filterListener =
function() {
	var loadCallback = new AjxCallback(this, this._handleLoadFilter);
	AjxDispatcher.require(["PreferencesCore", "Preferences"], false, loadCallback, null, true);
};

Com_Zimbra_Email.prototype._handleLoadFilter =
function() {
	appCtxt.getAppViewMgr().popView(true, ZmId.VIEW_LOADING);	// pop "Loading..." page
	var rule = new ZmFilterRule();

	var addr = this._getAddress(this._actionObject);
	if (AjxUtil.isString(addr) && this.isMailToLink(addr)) {
		addr = (this.parseMailToLink(addr)).to || addr;
	}
	var subjMod = ZmFilterRule.C_HEADER_VALUE[ZmFilterRule.C_FROM];
	rule.addCondition(ZmFilterRule.TEST_HEADER, ZmFilterRule.OP_IS, addr, subjMod);
	rule.addAction(ZmFilterRule.A_KEEP);

	appCtxt.getFilterRuleDialog().popup(rule);
};

Com_Zimbra_Email.prototype._goToUrlListener =
function() {
	var addr  = this._getAddress(this._actionObject);
	if (AjxUtil.isString(addr) && this.isMailToLink(addr)) {
		addr = (this.parseMailToLink(addr)).to || addr;
	}

	var parts = addr.split("@");
	if (parts.length) {
		var domain = parts[parts.length - 1];
		var pieces = domain.split(".");
		this._actionUrl = "http://" + ((pieces.length <= 2) ? 'www.' + domain : domain);
	}

	if (this._actionUrl) {
		window.open(this._actionUrl, "_blank");
	} else {
		this.displayStatusMessage(ZmMsg.errorCreateUrl);
	}
};

//------ the following added on top of com_zimbra_email zimlet for SCS integration ------

Com_Zimbra_Email.prototype._queryPresence =
function(sipid)
{
	var url = this.getResource("askPresence.jsp");
	var params= "who=" + AjxStringUtil.urlComponentEncode(sipid);
	var resp = AjxRpc.invoke(null, url+"?"+params, null, null, true);

	eval( "var jsonObj = " + resp.text);

	return jsonObj;
};

Com_Zimbra_Email.prototype._createPresenceView =
function(presence) {
	var html = [];
	var i = 0;
	html[i++] = "<FORM>";
	html[i++] = "<TABLE>";
	html[i++] = "<TR>";
	html[i++] = "<TD>Query Status:";
	html[i++] = "</TD>";
	html[i++] = "<TD>";
	html[i++] = "<input id='EPI_status'  size=" + presence.status.length + " type='text' value='" + presence.status+ "' readonly ='readonly'/>";
	html[i++] = "</TD>";
	html[i++] = "</TR>";
	html[i++] = "<TR id = 'eid_presence_errorcode'>";
	html[i++] = "<TD>Error code:";
	html[i++] = "</TD>";
	html[i++] = "<TD>";
	html[i++] = "<input id='EPI_error_code'  size=" + presence.errorCode.length + " type='text' value='" + presence.errorCode+ "' readonly ='readonly'/>";
	html[i++] = "</TD>";
	html[i++] = "</TR>";
	html[i++] = "<TR id = 'eid_presence_errorinfo'>";
	html[i++] = "<TD>Error info:";
	html[i++] = "</TD>";
	html[i++] = "<TD>";
	html[i++] = "<input id='EPI_error_info'  size=" + presence.errorInfo.length + " type='text' value='" + presence.errorInfo+ "' readonly ='readonly'/>";
	html[i++] = "</TD>";
	html[i++] = "</TR>";
	html[i++] = "<TR>";
	html[i++] = "<TD>IM Id:";
	html[i++] = "</TD>";
	html[i++] = "<TD>";
	html[i++] = "<input id='EPI_IM_Id'  size=" + presence.IM_Id.length + " type='text' value='" + presence.IM_Id+ "' readonly ='readonly'/>";
	html[i++] = "</TD>";
	html[i++] = "</TR>";
	html[i++] = "<TR>";
	html[i++] = "<TD>Full Name:";
	html[i++] = "</TD>";
	html[i++] = "<TD>";
	html[i++] = "<input id='EPI_fullname'  size=" + presence.fullname.length + " type='text' value='" + presence.fullname + "' readonly ='readonly'/>";
	html[i++] = "</TD>";
	html[i++] = "</TR>";
	html[i++] = "<TR>";
	html[i++] = "<TD>Unified Presence::";
	html[i++] = "</TD>";
	html[i++] = "<TD>";
	html[i++] = "<input id='EPI_unified_presence'  size=" + presence.up.length + " type='text' value='" + presence.up + "' readonly ='readonly'/>";
	html[i++] = "</TD>";
	html[i++] = "</TR>";
	html[i++] = "<TR>";
	html[i++] = "<TD>IM Presence:";
	html[i++] = "</TD>";
	html[i++] = "<TD>";
	html[i++] = "<input id='EPI_im_presence'  size=" + presence.xmpp.length + " type='text' value='" + presence.xmpp + "' readonly ='readonly'/>";
	html[i++] = "</TD>";
	html[i++] = "</TR>";
	html[i++] = "<TR>";
	html[i++] = "<TD>Phone Presence:";
	html[i++] = "</TD>";
	html[i++] = "<TD>";
	html[i++] = "<input id='EPI_phone_presence'  size=" + presence.sip.length + " type='text' value='" + presence.sip+ "' readonly ='readonly'/>";
	html[i++] = "</TD>";
	html[i++] = "</TR>";
	html[i++] = "<TR>";
	html[i++] = "<TD>Custom Message:";
	html[i++] = "</TD>";
	html[i++] = "<TD>";
	html[i++] = "<input id='EPI_cm'  size=" + presence.cm.length + " type='text' value='" + presence.cm+ "' readonly ='readonly'/>";
	html[i++] = "</TD>";
	html[i++] = "</TR>";
	html[i++] = "</TABLE>";
	html[i++] = "</FORM>";
	return html.join("");
};

Com_Zimbra_Email.prototype._initializeAddressBook = function() {
	this.isAddressbookInitialized = false;
	var  postCallback = new AjxCallback(this, this._normalizeContacts);
	this.loadAllContacts(postCallback);
};

Com_Zimbra_Email.prototype.loadAllContacts = function(postCallBack) {
	this.__oldNumContacts = 0;
	this._noOpLoopCnt = 0;
	this._totalWaitCnt = 0;

	if(this._contactsAreLoaded) {//2nd time onwards..
		if(postCallback) 
		{
			postCallback.run(this);
			return;
		}
	}
	var transitions = [ ZmToast.FADE_IN, ZmToast.PAUSE,  ZmToast.PAUSE,  ZmToast.PAUSE,  ZmToast.PAUSE,  ZmToast.FADE_OUT ];
	appCtxt.getAppController().setStatusMsg("Please wait, scanning Address Book(it might take up to a minute)..", ZmStatusView.LEVEL_INFO, null, transitions);
	this._contactsAreLoaded = false;
	this._waitForContactToLoadAndProcess(postCallBack);
	this._contactsAreLoaded = true;
};
Com_Zimbra_Email.prototype._waitForContactToLoadAndProcess = function(postCallback) {
	this._contactList = AjxDispatcher.run("GetContacts");
	if (!this._contactList)
	{
		return;
	}

	this.__currNumContacts = this._contactList.getArray().length;
	if (this._totalWaitCnt < 2 || this._noOpLoopCnt < 3) {//minimum 2 cycles post currentCnt==oldCnt
		if (this.__oldNumContacts == this.__currNumContact) {
			this._noOpLoopCnt++;
		}
		this._totalWaitCnt++;
		this.__oldNumContacts = this.__currNumContact;
		setTimeout(AjxCallback.simpleClosure(this._waitForContactToLoadAndProcess, this, postCallback), 5000);
	} else {//process..
		if(postCallback) {
			postCallback.run(this);
		}
	}
};

Com_Zimbra_Email.prototype._normalizeContacts =
function() {
	this.isAddressbookInitialized = true;	
	return;
};

Com_Zimbra_Email.prototype._getContactByEmail =
function(email) {
	if (!this._contactList)
	{
		alert(" AddressBook is not intialized!")
		return;
	}

	if (!this.isAddressbookInitialized)
	{
		alert(" AddressBook intialization is in process!")
		return;
	}

	var _tmpArry = this._contactList.getArray();

	for (var j = 0; j < _tmpArry.length; j++) 
	{
		var currentContact = _tmpArry[j];
		var attr = currentContact.attr ? currentContact.attr : currentContact._attrs;
		try 
		{
			currentContact._firstName = (attr.firstName) ? (attr.firstName).toLowerCase() : "-";
			currentContact._lastName = (attr.lastName) ? (attr.lastName).toLowerCase() : "-";
			currentContact._otherIM = (attr.otherPhone) ? attr.otherPhone : "-";

			currentContact._email = (attr.email) ? attr.email: "-";
			if (currentContact._email == email) {
				return currentContact;
			}
			currentContact._email2 = (attr.email2) ? attr.email2: "-";
			if (currentContact._email2 == email) {
				return currentContact;
			}
			currentContact._email3 = (attr.email3) ? attr.email3: "-";
			if (currentContact._email3 == email) {
				return currentContact;
			}
			currentContact._homeEmail= (attr.homeEmail) ? attr.homeEmail: "-";
			if (currentContact._homeEmail== email) {
				return currentContact;
			}
			currentContact._workEmail= (attr.workEmail) ? attr.workEmail: "-";
			if (currentContact._workEmail== email) {
				return currentContact;
			}
		} catch(e) {
		}

	}
		
	return null;
};
Com_Zimbra_Email.prototype._showPresence = 
function(contentObjText) {
	var theContact = this._getContactByEmail(contentObjText);
	var lastname = "unknown";
	var firstname = "unknown";
	var presence = {fullname:"unknown unknown", IM_Id: "unknown", cm : "N/A", up: "unknown", xmpp:"unknown", sip:"unknown", status: "unknown", errorCode:"unknown", errorInfo:"unknown"};
	if (theContact != null)
	{
		if (theContact._lastName)
		{
			lastname = theContact._lastName;
		}
		if (theContact._firstName)
		{
			firstname= theContact._firstName;
		}
		if (theContact._otherIM)
		{
			presence.IM_Id = theContact._otherIM;
		}
	

		presence.fullname = firstname + " " + lastname;
				
		var jsonobj = this._queryPresence(theContact._otherIM);
		if (jsonobj)
		{
			presence.status = jsonobj.status_code?jsonobj.status_code:"unknown";

			presence.errorCode =  jsonobj.error_code ?  jsonobj.error_code : "";
			presence.errorInfo =  jsonobj.error_info? jsonobj.error_info :"";
			if (jsonobj.custom_presence_message)
			{
				presence.cm = jsonobj.custom_presence_message;
			}
			if (jsonobj.unified_presence)
			{
				presence.up = jsonobj.unified_presence;
			}
			if (jsonobj.xmpp_presence)
			{
				presence.xmpp = jsonobj.xmpp_presence;
			}
			if (jsonobj.sip_presence)
			{
				presence.sip = jsonobj.sip_presence;
			}
		}
	}
	
	if (this._PresenceDialog) {

		this._PresenceDialog.popup();
		document.getElementById("EPI_fullname").value = presence.fullname;
		document.getElementById("EPI_fullname").size =  presence.fullname.length;
		document.getElementById("EPI_unified_presence").value = presence.up;
		document.getElementById("EPI_unified_presence").size = presence.up.length; 
		document.getElementById("EPI_im_presence").value = presence.xmpp;
		document.getElementById("EPI_im_presence").size = presence.xmpp.length; 
		document.getElementById("EPI_phone_presence").value = presence.sip;
		document.getElementById("EPI_phone_presence").size =  presence.sip.length;
		document.getElementById("EPI_cm").value = presence.cm;
		document.getElementById("EPI_cm").size =  presence.cm.length;
		document.getElementById("EPI_status").value = presence.status;
		document.getElementById("EPI_status").size =  presence.status.length;
		document.getElementById("EPI_IM_Id").value =  presence.IM_Id;
		document.getElementById("EPI_IM_Id").size =  presence.IM_Id.length;
	}
	else
	{
		this._PresenceDialogView = new DwtComposite(this.getShell());
		this._PresenceDialogView.getHtmlElement().style.overflow = "auto";
		this._PresenceDialogView.getHtmlElement().innerHTML = this._createPresenceView(presence);

		this._PresenceDialog = this._createDialog({title:"Presence Info", view:this._PresenceDialogView, standardButtons:[DwtDialog.CANCEL_BUTTON]});
		this._PresenceDialog.popup();
	}

	var row1 = document.getElementById("eid_presence_errorcode");
	var row2 = document.getElementById("eid_presence_errorinfo");
	if (presence.status == "ok")
	{
		row1.style.display = 'none';
		row2.style.display = 'none';
	}
	else
	{
		row1.style.display = '';
		row1.style.display = '';
	}
};

Com_Zimbra_Email.prototype._getProcessedNumber=
function(calledNumber, prefix_remove, prefix_add) 
{
	if (calledNumber.length >= prefix_remove.length)
	{
		if (calledNumber.substr(0, prefix_remove.length) == prefix_remove)
		{
			if (calledNumber.length == prefix_remove.length)
			{
				calledNumber = "";
			}
			else
			{
				var strtokeep = calledNumber.substr(prefix_remove.length);
				calledNumber = strtokeep;
			}
		}
	}

	return this._removeInvalidLetters(prefix_add + calledNumber);
};

Com_Zimbra_Email.prototype._removeInvalidLetters = 
function (strtocheck) {

		var cleanNumber ='';
		var hh;

		for(var j=0; j<strtocheck.length; j++)
		{
		  hh = strtocheck.charAt(j);
		  if((hh >= '0' && hh <= '9') || (hh >= 'a' && hh <= 'z') || (hh >= 'A' && hh <= 'Z'))
		  {
			cleanNumber = cleanNumber + hh;
		  }
		}
		
		return cleanNumber;
};
Com_Zimbra_Email.prototype._checkForAlphaOnlyReg = 
function (strtocheck) {
	return (/^[0-9a-zA-Z]*$/).test(strtocheck);
};
Com_Zimbra_Email.prototype._checkForNumberOnlyReg = 
function (strtocheck) {
	return (/^[0-9]*$/).test(strtocheck);
};
Com_Zimbra_Email.prototype._PostRestCall = 
function(calledNumber) {
    calledNumber = this._removeInvalidLetters(calledNumber);
    this._clickToCall(calledNumber);
    return;
};
Com_Zimbra_Email.prototype._PostRestCall2 = 
function(callingNumber, calledNumber) {
    callingNumber = this._removeInvalidLetters(callingNumber);
    calledNumber = this._removeInvalidLetters(calledNumber);
    this._clickToCall2(callingNumber, calledNumber);
    return;
};
Com_Zimbra_Email.prototype.getClick2CallURL =
function(phoneNumberToCall) {

	if (this.scs_sslenabled == 1)
	{
		return "https://" + this.scs_server + ":" + this.scs_port + "/callcontroller/" + this.scs_user+"/" + phoneNumberToCall;
	}

	return "http://" + this.scs_server + ":" + this.scs_port + "/callcontroller/" + this.scs_user+"/" + phoneNumberToCall;
};

Com_Zimbra_Email.prototype.getClick2CallURL2 =
function(fromNumber, phoneNumberToCall) {
	var url;

	if (this.scs_sslenabled == 1)
	{
		url = "https://" + this.scs_server + ":" + this.scs_port+ "/callcontroller/" + fromNumber +"/" + phoneNumberToCall;
	}
	else
	{
		url = "http://" + this.scs_server + ":" + this.scs_port + "/callcontroller/" + fromNumber +"/" + phoneNumberToCall;
	}

	var params= ["agent=" + AjxStringUtil.urlComponentEncode(this.scs_user),
			"timeout=" + AjxStringUtil.urlEncode("30")
			].join ("&");

	return url + "?" + params;
};

Com_Zimbra_Email.prototype._setZimletCurrentPreferences =
function()
{
	try {
		var url = this.getResource("getSCSConfig.jsp");
		var params= "who=" + AjxStringUtil.urlComponentEncode("nouse");
		var resp = AjxRpc.invoke(null, url + "?" + params, null, null, true);

		eval( "var jsonObj2 = " + resp.text);

		if (jsonObj2)
		{
			this.scs_sslenabled = (jsonObj2.sslenabled == "1"? 1 : 0);
			this.prefix_remove = jsonObj2.prefixremove;
			this.prefix_add = jsonObj2.prefixadd;
			this.scs_server = jsonObj2.server;
			this.scs_port = jsonObj2.port;
			this.scs_user = jsonObj2.user;
			this.scs_password = jsonObj2.password;
		}
		else
		{
	
			this.scs_sslenabled = 1;
			this.prefix_remove = "";
			this.prefix_add = "";
			this.scs_server = "unknown";
			this.scs_port = "8043";
			this.scs_user = "anonymous";
			this.scs_password = "unknown";
		}

		;
	}
	catch(err)
	{
		  txt="There was an error on this page.\n\n";
		  txt+="Error description: " + err.description + "\n\n";
		  txt+="Click OK to continue.\n\n";
		  alert(txt);
	 }
};
//===========
Com_Zimbra_Email.prototype._clickToCall =
function(toPhoneNumber) {
	var hdrs = [];
	if (this.scs_sslenabled == 1)
	{
		hdrs.Authorization = this.make_basic_auth(this.scs_user, this.scs_password);
	}
	var feedUrl = ZmZimletBase.PROXY + AjxStringUtil.urlComponentEncode(this.getClick2CallURL(toPhoneNumber));
	AjxRpc.invoke(null, feedUrl, hdrs, new AjxCallback(this, this._reponseHandler), false);
};
Com_Zimbra_Email.prototype._clickToCall2 =
function(callingNumber, toPhoneNumber) {
	var hdrs = [];
	if (this.scs_sslenabled == 1)
	{
		hdrs.Authorization = this.make_basic_auth(this.scs_user, this.scs_password);
	}
	var feedUrl = ZmZimletBase.PROXY + AjxStringUtil.urlComponentEncode(this.getClick2CallURL2(callingNumber, toPhoneNumber));
	AjxRpc.invoke(null, feedUrl, hdrs, new AjxCallback(this, this._reponseHandler), false);
};
Com_Zimbra_Email.prototype._reponseHandler =
function(response) {
	if (!response.success)
	{
		alert("Failed to call! status:" + response.status + "\n" + response.text);
	}
};
//===========


Com_Zimbra_Email.prototype.make_basic_auth =
function (user, password) {
  var tok = user + ':' + password;
  var hash = Base64.encode(tok);
  return "Basic " + hash;
};

Com_Zimbra_Email.prototype._showCallDlg = function(email) 
{
	this._setZimletCurrentPreferences();

	var respCallback = new AjxCallback(this, this._callContact, email);
	var transitions = [ ZmToast.FADE_IN, ZmToast.PAUSE, ZmToast.PAUSE, ZmToast.PAUSE, ZmToast.PAUSE, ZmToast.PAUSE, ZmToast.FADE_OUT ];
	appCtxt.getAppController().setStatusMsg("Please wait, scanning Address Book for Contact numbers..", ZmStatusView.LEVEL_INFO, null, transitions);
	appCtxt.getApp(ZmApp.CONTACTS).getContactByEmail(email, respCallback);
};

Com_Zimbra_Email.prototype._callContact = function(email, contact, isContactSrcObj) {

	if(contact === undefined || contact === null) {
		appCtxt.getAppController().setStatusMsg("No Contact found for this email: "+email, ZmStatusView.LEVEL_WARNING);
		return;
	} 

	if(isContactSrcObj === undefined)
	{
		isContactSrcObj = true;
	}

	this._showChooseDlg(contact, isContactSrcObj);

	return;
}
Com_Zimbra_Email.prototype._validateIP = 
function (strtocheck) {
	var filter = /^(([1-9][0-9]{0,2})|0)\.(([1-9][0-9]{0,2})|0)\.(([1-9][0-9]{0,2})|0)\.(([1-9][0-9]{0,2})|0)$/;
	return filter.test(strtocheck);
};


Com_Zimbra_Email.prototype._showChooseDlg = 
function(ZmObj, isSrcObj) {

	var prefix_remove_loc = this.prefix_remove;
	var prefix_add_loc = this.prefix_add; 

	if (this._ChooseDialog) 
	{
		this._ChooseDialog.popup();

		this._removeAllOptions(document.getElementById("ElistNumbers"));

		if (isSrcObj)
		{
			if (ZmObj.attr.workPhone)
			{
				this._addOption(document.getElementById("ElistNumbers"), "work", ZmObj.attr.workPhone);
			}
			if (ZmObj.attr.workPhone2)
			{
				this._addOption(document.getElementById("ElistNumbers"), "work2", ZmObj.attr.workPhone2);
			}
			if (ZmObj.attr.homePhone)
			{
				this._addOption(document.getElementById("ElistNumbers"),  "home", ZmObj.attr.homePhone);
			}
			if (ZmObj.attr.homePhone2)
			{
				this._addOption(document.getElementById("ElistNumbers"),  "home2", ZmObj.attr.homePhone2);
			}
			if (ZmObj.attr.mobilePhone)
			{
				this._addOption(document.getElementById("ElistNumbers"),  "mobile", ZmObj.attr.mobilePhone);
			}
			if (ZmObj.attr.otherPhone)
			{
				this._addOption(document.getElementById("ElistNumbers"),  "other", ZmObj.attr.otherPhone);
			}
		}

		else
		{
			if (ZmObj.workPhone)
			{
				this._addOption(document.getElementById("ElistNumbers"), "work", ZmObj.workPhone);
			}
			if (ZmObj.homePhone)
			{
				this._addOption(document.getElementById("ElistNumbers"),  "home", ZmObj.homePhone);
			}
			if (ZmObj.workPhone2)
			{
				this._addOption(document.getElementById("ElistNumbers"), "work2", ZmObj.workPhone2);
			}
			if (ZmObj.homePhone2)
			{
				this._addOption(document.getElementById("ElistNumbers"),  "home2", ZmObj.homePhone2);
			}
			if (ZmObj.mobilePhone)
			{
				this._addOption(document.getElementById("ElistNumbers"),  "mobile", ZmObj.mobilePhone);
			}
			if (ZmObj.otherPhone)
			{
				this._addOption(document.getElementById("ElistNumbers"),  "other", ZmObj.otherPhone);
			}
		}

		document.getElementById("ElistNumbers").onchange = function()
		{ 
			var calledNumber = document.getElementById("ElistNumbers").value;
			if (calledNumber.length >= prefix_remove_loc.length)
			{
				if (calledNumber.substr(0, prefix_remove_loc.length) == prefix_remove_loc)
				{
					if (calledNumber.length == prefix_remove_loc.length)
					{
						calledNumber = "";
					}
					else
					{
						var strtokeep = calledNumber.substr(prefix_remove_loc.length);
						calledNumber = strtokeep;
					}
				}
			}

			calledNumber = prefix_add_loc + calledNumber;
			var cleanNumber ='';
			var hh;

			for(var j=0; j<calledNumber.length; j++)
			{
			  hh = calledNumber.charAt(j);
			  if(hh >= '0' && hh <= '9')
			  {
				cleanNumber = cleanNumber + hh;
			  }
			}
		
	  		document.getElementById("Enumbertocall").value = cleanNumber;
		};

		document.getElementById("Enumbertocall").value = this._getProcessedNumber(document.getElementById("ElistNumbers").value, this.prefix_remove, this.prefix_add);

		return;
	}
	this._ChooseDialogView = new DwtComposite(this.getShell());
	this._ChooseDialogView.getHtmlElement().style.overflow = "auto";
	this._ChooseDialogView.getHtmlElement().innerHTML = this._createChooseView(ZmObj, isSrcObj);

	this._ChooseDialog = this._createDialog({title:"Call", view:this._ChooseDialogView, standardButtons:[DwtDialog.OK_BUTTON, DwtDialog.CANCEL_BUTTON]});
	this._ChooseDialog.setButtonListener(DwtDialog.OK_BUTTON, new AjxListener(this, this._okChooseBtnListener));
	this._ChooseDialog.popup();

	document.getElementById("ElistNumbers").onchange = function()
	{ 
		var calledNumber = document.getElementById("ElistNumbers").value;
		if (calledNumber.length >= prefix_remove_loc.length)
		{
			if (calledNumber.substr(0, prefix_remove_loc.length) == prefix_remove_loc)
			{
				if (calledNumber.length == prefix_remove_loc.length)
				{
					calledNumber = prefix_add_loc;
				}
				else
				{
					var strtokeep = calledNumber.substr(prefix_remove_loc.length);
					calledNumber = prefix_add_loc + strtokeep;
				}
			}
		}

		var cleanNumber ='';
		var hh;

		for(var j=0; j<calledNumber.length; j++)
		{
		  hh = calledNumber.charAt(j);
		  if(hh >= '0' && hh <= '9')
		  {
			cleanNumber = cleanNumber + hh;
		  }
		}

	  	document.getElementById("Enumbertocall").value = cleanNumber;
	};
	
	document.getElementById("Enumbertocall").value = this._getProcessedNumber(document.getElementById("ElistNumbers").value, this.prefix_remove, this.prefix_add);
};

Com_Zimbra_Email.prototype._removeAllOptions = function (selectbox)
{
	var i;
	for(i = selectbox.options.length-1;i>=0;i--)
	{
		selectbox.remove(i);
	}
};

Com_Zimbra_Email.prototype._addOption = function (selectbox,text,value)
{
var optn = document.createElement("OPTION");
optn.text = text;
optn.value = value;
selectbox.options.add(optn);
};


Com_Zimbra_Email.prototype._createChooseView =
function(ZmObject, isSrcObj) 
{
	var html = [];
	var i = 0;

	html[i++] = "<TABLE>";
	html[i++] = "<TR>";
	html[i++] = "<TD>";
	html[i++] = "<input type='radio' id='EFromType1_C' name='EFromType_C' value='1' checked>using primary phone";
	html[i++] = "</TD></TR><TR>";
	html[i++] = "<TD>";
	html[i++] = "<input type='radio' id='EFromType2_C' name='EFromType_C' value='2'>using the following phone";
	html[i++] = "</TD><TD>";
	html[i++] = "<input id='EFromNumber_C' name='EFromNumber_CName' type='text' value=''/>";
	html[i++] = "</TD>";
	html[i++] = "</TR>";
	html[i++] = "</TABLE><br>";
	html[i++] = "<TABLE>";
	html[i++] = "<TR>";
	html[i++] = "<TD>Call:</TD>";
	html[i++] = "<TD>";

	html[i++] = "<select id='ElistNumbers'>";
	
	if (isSrcObj)
	{
		if (ZmObject.attr.workPhone)
		{
			html[i++] = "<option value='"+ ZmObject.attr.workPhone+ "'>work</option>";
		}
		if (ZmObject.attr.homePhone)
		{
			html[i++] = "<option value='"+ ZmObject.attr.homePhone+ "'>home</option>";
		}
		if (ZmObject.attr.workPhone2)
		{
			html[i++] = "<option value='"+ ZmObject.attr.workPhone2+ "'>work2</option>";
		}
		if (ZmObject.attr.homePhone2)
		{
			html[i++] = "<option value='"+ ZmObject.attr.homePhone2+ "'>home2</option>";
		}
		if (ZmObject.attr.mobilePhone)
		{
			html[i++] = "<option value='"+ ZmObject.attr.mobilePhone+ "'>mobile</option>";
		}
		if (ZmObject.attr.otherPhone)
		{
			html[i++] = "<option value='"+ ZmObject.attr.otherPhone+ "'>other</option>";
		}
	}
	else
	{
	
		if (ZmObject.workPhone)
		{
			html[i++] = "<option value='"+ ZmObject.workPhone+ "'>work</option>";
		}
		if (ZmObject.homePhone)
		{
			html[i++] = "<option value='"+ ZmObject.homePhone+ "'>home</option>";
		}
		if (ZmObject.workPhone2)
		{
			html[i++] = "<option value='"+ ZmObject.workPhone2+ "'>work2</option>";
		}
		if (ZmObject.homePhone2)
		{
			html[i++] = "<option value='"+ ZmObject.homePhone2+ "'>home2</option>";
		}
		if (ZmObject.mobilePhone)
		{
			html[i++] = "<option value='"+ ZmObject.mobilePhone+ "'>mobile</option>";
		}
		if (ZmObject.otherPhone)
		{
			html[i++] = "<option value='"+ ZmObject.otherPhone+ "'>other</option>";
		}
	}

	html[i++] = "</select>";
	html[i++] = "</TD>";
	html[i++] = "<TD>";
	html[i++] = "<input id='Enumbertocall'  type='text'/>";
	html[i++] = "</TD>";
	html[i++] = "</TR>";
	html[i++] = "</TABLE>";

	return html.join("");
};

Com_Zimbra_Email.prototype._okChooseBtnListener =
function() {

	var numbertocall = document.getElementById("Enumbertocall").value;
	if (!this._checkForAlphaOnlyReg(numbertocall))
	{
		alert("Invalid letters found! remove them and try again");
		return;
	}

	if (document.getElementById("EFromType2_C").checked)
	{
		var FromNumber = document.getElementById("EFromNumber_C").value;
		if (!this._checkForAlphaOnlyReg(FromNumber))
		{
			alert("Invalid letters found in originating number! remove them and try again");
			return;
		}

		this._PostRestCall2(FromNumber, numbertocall);
	}

	else
	{

		this._PostRestCall(numbertocall);
	}
	this._ChooseDialog.popdown();
};
