DB=rubytest
USER=jim
PW=""
TABLE1=names
TABLE2=datatypes
