DB=dbitest
TABLE1=names
TABLE2=datatypes
