extern int WWWLib_Init(Tcl_Interp *interp);

extern void WWWLib_Terminate(void);
