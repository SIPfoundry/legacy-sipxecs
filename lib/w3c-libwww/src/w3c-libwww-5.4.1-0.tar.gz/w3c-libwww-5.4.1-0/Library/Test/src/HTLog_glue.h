#include "Libdata.h"
#include "Enumerations.h"


extern int HTLog_open_tcl(ClientData, Tcl_Interp *, int, char **);

extern int HTLog_close_tcl(ClientData, Tcl_Interp *, int, char **);

extern int HTLog_isOpen_tcl(ClientData, Tcl_Interp *, int, char **);

extern int HTLog_add_tcl(ClientData, Tcl_Interp *, int, char **);
